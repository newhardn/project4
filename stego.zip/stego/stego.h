#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define START_FROM 100
