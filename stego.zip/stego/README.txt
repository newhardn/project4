It is suggested that you compile these programs using gcc 
(in Windows, use cygwin). For some reason, Microsoft visual 
studio does not seem to like these programs.

The program stegoRead.c will read information that was embedded 
in an image file use the program stego.c.

